﻿using dmClone.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace dmClone.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration configuration;
        private readonly IApp repo;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration, IApp repo)
        {
            _logger = logger;
            this.configuration = configuration;
            this.repo = repo;
        }

        public IActionResult Index()
        {
            List<Inventory> Names = repo.GetAllPatientRecords();
            return View(Names);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}