﻿using dmClone.Models;
using Microsoft.AspNetCore.Mvc;

namespace dmClone.Components
{
    public class SearchViewComponent:ViewComponent
    {
        private readonly IConfiguration configuration;
        private readonly IApp repo;

        public SearchViewComponent(IConfiguration configuration, IApp repo)
        {
            this.configuration = configuration;
            this.repo = repo;
        }
        public IViewComponentResult Invoke()
        {
            List<Inventory> Names = repo.GetAllPatientRecords();
            return View(Names);
        }
    }
}
