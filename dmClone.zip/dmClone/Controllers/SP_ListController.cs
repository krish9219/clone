﻿using Microsoft.AspNetCore.Mvc;

namespace dmClone.Controllers
{
    public class SP_ListController : Controller
    {
        public IActionResult sp_list()
        {
            return View();
        }
    }
}
