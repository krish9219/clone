﻿using System.Data.SqlClient;

namespace dmClone.Models
{
    public class DataPullFromDB : IApp
    {

        SqlConnection con = null; // Class used for making a connection between the application and database
        SqlCommand com = null;// class used for building and executing our SQL comand (DML)
        SqlDataReader reader = null;// Class used for fetching the data alone.
        string connectionString;

        private readonly IConfiguration configuration;

        public DataPullFromDB(IConfiguration configuration)
        {
            this.configuration = configuration;
            connectionString = this.configuration.GetConnectionString("dbCon");
        }

        public List<Inventory> GetAllPatientRecords()
        {
            con = new SqlConnection(connectionString);
            con.Open();
            com = new SqlCommand("Select * from PatientDetails", con);//Building the SQL query to run against our database 
            reader = com.ExecuteReader();//Execute the query .
            List<Inventory> names = new List<Inventory>();
            while (reader.Read())
            {
                Inventory name = new Inventory();
                name.PatientId = reader.GetInt32(0);// First column
                name.PatientName = reader.GetString(1);//second column 
                name.Email = reader.GetString(2);
                name.Contact = reader.GetString(3);
                name.PatientHistory = reader.GetString(4);
                names.Add(name);
            }
            reader.Close();
            con.Close();
            return names;
        }
    }
}
