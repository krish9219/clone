﻿namespace dmClone.Models
{
    public class Inventory
    {
        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public string Email { get; set; }
        public string Contact { get; set; }
        public string PatientHistory { get; set; }
    }
}
