﻿namespace dmClone.Models
{
    public interface IApp
    {
        List<Inventory> GetAllPatientRecords();
    }
}
