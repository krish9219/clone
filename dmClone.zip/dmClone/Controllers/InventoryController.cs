﻿using dmClone.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Configuration;

namespace dmClone.Controllers
{
    public class InventoryController : Controller
    {
        private readonly IConfiguration configuration;
        private readonly IApp repo;

        public InventoryController(IConfiguration configuration, IApp repo)
        {
            this.configuration = configuration;
            this.repo = repo;
        }

        public IActionResult Inventory()
        {
            List<Inventory> Names = repo.GetAllPatientRecords();
            return View(Names);
        }
    }
}
